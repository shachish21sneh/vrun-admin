import EditMerchantPage from "@/components/sections/merchants/views/EditMerchantPage";

export default function MerchantEdit() {
  return <EditMerchantPage />;
}