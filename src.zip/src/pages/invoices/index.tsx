import React from "react";
import DashboardLayout from "@/components/layout/DashboardLayout";

export const metadata = {
  title: "Dashboard : Employees",
};

export default function Page() {
  return (
    <DashboardLayout>
      <div />
    </DashboardLayout>
  );
}
