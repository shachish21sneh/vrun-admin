export { default as BannersListingPage } from "../banners-table/banners-listing-page";
