export { default as TestimonialsListingPage } from "../testimonials-table/testimonials-listing-page";
