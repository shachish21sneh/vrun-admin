export { default as TechniciansListingPage } from '../technicians-tables/technicians-listing-page';
