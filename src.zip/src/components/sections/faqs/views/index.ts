export { default as FaqsListingPage } from "../faqs-table/faqs-listing-page";
