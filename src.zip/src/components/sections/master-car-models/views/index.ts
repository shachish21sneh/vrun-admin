export { default as MasterCarModelsListingPage } from "../master-car-models-table/master-car-models-listing-page";
