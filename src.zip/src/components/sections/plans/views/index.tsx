import { PlansListingPage } from "@/components/sections/plans/plans-table/plans-listing-page";

export default function PlansPage() {
  return <PlansListingPage />;
}