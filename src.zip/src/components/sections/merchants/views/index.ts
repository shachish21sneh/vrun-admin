export { default as MerchantsListingPage } from '../merchants-tables/merchants-listing-page';
