export { default as MasterCarBrandsListingPage } from "../master-car-brands-table/master-car-brands-listing-page";
