export const V_AUTH_TOKEN = "V_AUTH_TOKEN";
export const V_REFRESH_TOKEN = "V_REFRESH_TOKEN";
